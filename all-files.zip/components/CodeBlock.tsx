import React, { useState } from 'react';
import { IconCode } from './Icons';

interface CodeBlockProps {
  code: string;
  language?: string;
}

const CodeBlock: React.FC<CodeBlockProps> = ({ code, language }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy code', err);
    }
  };

  return (
    <div className="my-4 rounded-lg overflow-hidden border border-gray-700 bg-gray-950 group">
      <div className="flex justify-between items-center px-4 py-2 bg-gray-900 border-b border-gray-800">
        <div className="flex items-center gap-2 text-xs text-gray-400 uppercase font-mono">
            <IconCode className="w-3 h-3" />
            <span>{language || 'plaintext'}</span>
        </div>
        <button 
          onClick={handleCopy}
          className={`flex items-center gap-1.5 px-3 py-1 rounded text-xs font-medium transition-all duration-200 border ${
             copied 
             ? 'bg-green-900/20 border-green-800 text-green-400' 
             : 'bg-gray-800 border-gray-700 text-gray-300 hover:bg-gray-700 hover:text-white'
          }`}
        >
          {copied ? (
             <>
                <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                    <polyline points="20 6 9 17 4 12"></polyline>
                </svg>
                Copied
             </>
          ) : (
             <>
                <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                    <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
                </svg>
                Copy Code
             </>
          )}
        </button>
      </div>
      <div className="relative">
          <div className="p-4 overflow-x-auto custom-scrollbar">
            <pre className="text-sm font-mono text-gray-300 whitespace-pre leading-relaxed">
              {code}
            </pre>
          </div>
      </div>
    </div>
  );
};

export default CodeBlock;