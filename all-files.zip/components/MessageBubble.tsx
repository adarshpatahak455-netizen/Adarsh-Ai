import React from 'react';
import { Message } from '../types';
import { IconLoader, IconFile } from './Icons';
import CodeBlock from './CodeBlock';

interface MessageBubbleProps {
  message: Message;
}

const MessageBubble: React.FC<MessageBubbleProps> = ({ message }) => {
  const isUser = message.role === 'user';

  // Robust parser for code blocks
  const renderContent = (text: string) => {
    if (!text) return null;

    // Split by code blocks (capturing the delimiter content)
    // This regex matches ```lang? ... ```
    const parts = text.split(/(```[\s\S]*?```)/g);
    
    return parts.map((part, index) => {
      if (part.startsWith('```')) {
        // Extract language and code
        // Match ```language\ncode``` or just ```code```
        const match = part.match(/```(\w+)?\s*([\s\S]*?)```/);
        if (match) {
          const language = match[1] || '';
          const code = match[2] || '';
          return <CodeBlock key={index} language={language} code={code} />;
        }
      }
      // Plain text
      if (!part) return null;
      return <span key={index} className="whitespace-pre-wrap break-words">{part}</span>;
    });
  };

  return (
    <div className={`flex w-full ${isUser ? 'justify-end' : 'justify-start'} mb-6`}>
      <div className={`max-w-[85%] md:max-w-[75%] flex flex-col ${isUser ? 'items-end' : 'items-start'}`}>
        
        {/* Role Label */}
        <span className="text-xs text-gray-500 mb-1 font-mono uppercase">
            {message.role === 'model' ? 'Adarsh AI' : 'User'}
        </span>

        <div className={`relative p-4 rounded-2xl ${
          isUser 
            ? 'bg-gray-800 text-white rounded-tr-none' 
            : 'bg-transparent border border-gray-700 text-gray-200 rounded-tl-none'
        }`}>
            {/* Text Content */}
            {message.text && (
                <div className="text-sm leading-relaxed">
                    {renderContent(message.text)}
                </div>
            )}

            {/* Attachments (Images & Files) */}
            {message.attachments && message.attachments.length > 0 && (
                <div className="mt-3 flex flex-wrap gap-2">
                    {message.attachments.map((att, idx) => (
                        <React.Fragment key={idx}>
                            {att.mimeType.startsWith('image/') && att.inlineData ? (
                                <div className="rounded-lg overflow-hidden border border-gray-700 max-w-xs">
                                    <img 
                                        src={`data:${att.mimeType};base64,${att.inlineData.data}`} 
                                        alt={att.name || 'Attachment'} 
                                        className="w-full h-auto" 
                                    />
                                </div>
                            ) : (
                                <div className="flex items-center gap-2 p-2 bg-gray-900 border border-gray-700 rounded-lg text-xs text-gray-300">
                                    <IconFile className="w-4 h-4 text-blue-400" />
                                    <span className="truncate max-w-[150px]">{att.name || 'Document'}</span>
                                </div>
                            )}
                        </React.Fragment>
                    ))}
                </div>
            )}

            {/* Backward compatibility for old imageUri */}
            {!message.attachments && message.imageUri && (
                <div className="mt-3 rounded-lg overflow-hidden border border-gray-700 max-w-sm">
                    <img src={message.imageUri} alt="Generated or Uploaded" className="w-full h-auto" />
                </div>
            )}

            {/* Loading State */}
            {message.isLoading && (
                <div className="flex items-center gap-2 mt-2 text-blue-400 text-sm font-mono">
                    <IconLoader className="w-4 h-4" />
                    <span>Processing...</span>
                </div>
            )}
            
            {/* Error State */}
            {message.error && (
                 <div className="mt-2 text-red-400 text-xs font-mono">
                    {message.text?.includes('Error') ? '' : 'Error generating response.'}
                </div>
            )}
        </div>
      </div>
    </div>
  );
};

export default MessageBubble;