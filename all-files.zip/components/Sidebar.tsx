import React from 'react';
import { AppMode } from '../types';
import { IconMessage, IconImage, IconEdit, IconCode, IconLive } from './Icons';

interface SidebarProps {
  currentMode: AppMode;
  setMode: (mode: AppMode) => void;
  onNewSession: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ currentMode, setMode, onNewSession }) => {
  const modes = [
    { id: AppMode.Chat, label: 'Chat & Vision', icon: IconMessage },
    { id: AppMode.Live, label: 'Live Realtime', icon: IconLive },
    { id: AppMode.ImageGen, label: 'Image Studio', icon: IconImage },
    { id: AppMode.ImageEdit, label: 'Image Editor', icon: IconEdit },
  ];

  return (
    <aside className="hidden md:flex w-64 flex-col bg-gray-950 border-r border-gray-800 h-screen sticky top-0">
      <div className="p-6 flex items-center gap-3 border-b border-gray-800">
        <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center text-white">
            <IconCode className="w-5 h-5" />
        </div>
        <h1 className="font-bold text-lg tracking-tight text-white">Adarsh AI</h1>
      </div>

      <div className="p-4">
        <button 
          onClick={onNewSession}
          className="w-full py-2.5 px-4 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm font-medium transition-colors flex items-center justify-center gap-2 mb-6"
        >
          <span>+ New Session</span>
        </button>

        <div className="space-y-1">
          <p className="px-4 text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">Modes</p>
          {modes.map((mode) => (
            <button
              key={mode.id}
              onClick={() => setMode(mode.id)}
              className={`w-full flex items-center gap-3 px-4 py-2.5 text-sm rounded-lg transition-colors ${
                currentMode === mode.id 
                  ? 'bg-gray-800 text-blue-400' 
                  : 'text-gray-400 hover:bg-gray-900 hover:text-gray-200'
              }`}
            >
              <mode.icon className="w-4 h-4" />
              {mode.label}
            </button>
          ))}
        </div>
      </div>

      <div className="mt-auto p-4 border-t border-gray-800">
        <div className="text-xs text-gray-600 font-mono text-center">
          Powered by Google GenAI SDK
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;