import React from 'react';
import { GenerationConfig, AppMode, ModelType } from '../types';
import { MODEL_LABELS } from '../constants';
import { IconSettings } from './Icons';

interface ConfigPanelProps {
  mode: AppMode;
  config: GenerationConfig;
  setConfig: (config: GenerationConfig) => void;
  selectedModel: string;
  setModel: (model: string) => void;
}

const ConfigPanel: React.FC<ConfigPanelProps> = ({ mode, config, setConfig, selectedModel, setModel }) => {
  
  const getAvailableModels = () => {
    switch(mode) {
      case AppMode.Chat:
        return [ModelType.GeminiFlash, ModelType.GeminiPro];
      case AppMode.ImageGen:
        return [ModelType.GeminiFlashImage, ModelType.GeminiProImage];
      case AppMode.ImageEdit:
        return [ModelType.GeminiFlashImage, ModelType.GeminiProImage];
      default:
        return [];
    }
  };

  const handleChange = (key: keyof GenerationConfig, value: any) => {
    setConfig({ ...config, [key]: value });
  };

  return (
    <aside className="hidden lg:flex w-72 flex-col bg-gray-950 border-l border-gray-800 h-screen sticky top-0 overflow-y-auto">
      <div className="p-6 border-b border-gray-800 flex items-center gap-2">
        <IconSettings className="w-4 h-4 text-gray-400" />
        <h2 className="font-semibold text-sm text-gray-200">Run Settings</h2>
      </div>

      <div className="p-6 space-y-8">
        {/* Model Selector */}
        <div className="space-y-2">
          <label className="text-xs font-medium text-gray-400 uppercase">Model</label>
          <select 
            value={selectedModel}
            onChange={(e) => setModel(e.target.value)}
            className="w-full bg-gray-900 border border-gray-700 rounded-md px-3 py-2 text-sm text-gray-200 focus:outline-none focus:border-blue-600"
          >
            {getAvailableModels().map(model => (
              <option key={model} value={model}>{MODEL_LABELS[model]}</option>
            ))}
          </select>
        </div>

        {/* Temperature */}
        {mode === AppMode.Chat && (
          <div className="space-y-4">
            <div className="flex justify-between">
                <label className="text-xs font-medium text-gray-400 uppercase">Temperature</label>
                <span className="text-xs font-mono text-gray-500">{config.temperature}</span>
            </div>
            <input 
              type="range" 
              min="0" 
              max="2" 
              step="0.1"
              value={config.temperature}
              onChange={(e) => handleChange('temperature', parseFloat(e.target.value))}
              className="w-full h-1 bg-gray-800 rounded-lg appearance-none cursor-pointer accent-blue-600"
            />
          </div>
        )}

        {/* Max Tokens */}
        {mode === AppMode.Chat && (
          <div className="space-y-4">
             <div className="flex justify-between">
                <label className="text-xs font-medium text-gray-400 uppercase">Output Tokens</label>
                <span className="text-xs font-mono text-gray-500">{config.maxOutputTokens}</span>
            </div>
             <input 
              type="range" 
              min="100" 
              max="8192" 
              step="100"
              value={config.maxOutputTokens}
              onChange={(e) => handleChange('maxOutputTokens', parseInt(e.target.value))}
              className="w-full h-1 bg-gray-800 rounded-lg appearance-none cursor-pointer accent-blue-600"
            />
          </div>
        )}

        {/* System Instruction */}
        {mode === AppMode.Chat && (
            <div className="space-y-2">
                 <label className="text-xs font-medium text-gray-400 uppercase">System Instructions</label>
                 <textarea
                    value={config.systemInstruction}
                    onChange={(e) => handleChange('systemInstruction', e.target.value)}
                    className="w-full h-40 bg-gray-900 border border-gray-700 rounded-md p-3 text-xs text-gray-300 focus:outline-none focus:border-blue-600 resize-none font-mono"
                    placeholder="Enter system instructions..."
                 />
            </div>
        )}
      </div>
    </aside>
  );
};

export default ConfigPanel;