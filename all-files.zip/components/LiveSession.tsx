import React, { useEffect, useRef, useState } from 'react';
import { GeminiLiveSession } from '../services/geminiService';
import { IconVideoOn, IconVideoOff, IconPhoneHangup, IconLoader, IconLive } from './Icons';

interface LiveSessionProps {
    onClose: () => void;
}

const LiveSession: React.FC<LiveSessionProps> = ({ onClose }) => {
    const [status, setStatus] = useState('Initializing...');
    const [isCameraOn, setIsCameraOn] = useState(true);
    const videoRef = useRef<HTMLVideoElement>(null);
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const sessionRef = useRef<GeminiLiveSession | null>(null);
    const frameIntervalRef = useRef<any>(null);
    const mountedRef = useRef<boolean>(true);

    useEffect(() => {
        mountedRef.current = true;

        const startSession = async () => {
            const session = new GeminiLiveSession();
            sessionRef.current = session;
            
            try {
                await session.start((s) => {
                    if (mountedRef.current) setStatus(s);
                });
                if (mountedRef.current) {
                    startVideo();
                }
            } catch (e) {
                if (mountedRef.current) {
                    setStatus("Connection Failed");
                    console.error(e);
                }
            }
        };

        startSession();

        return () => {
            mountedRef.current = false;
            if (frameIntervalRef.current) clearInterval(frameIntervalRef.current);
            sessionRef.current?.disconnect();
        };
    }, []);

    const startVideo = async () => {
        if (!mountedRef.current) return;

        try {
            const stream = await navigator.mediaDevices.getUserMedia({ video: { width: 640, height: 480 } });
            
            if (videoRef.current && mountedRef.current) {
                videoRef.current.srcObject = stream;
                // Handle the play promise to avoid "interrupted by new load request" errors
                videoRef.current.onloadedmetadata = async () => {
                    try {
                        if (videoRef.current && mountedRef.current) {
                            await videoRef.current.play();
                        }
                    } catch (e) {
                        // Ignore interruption errors (e.g., user closed modal quickly)
                        console.debug("Video play interrupted", e);
                    }
                };
                
                // Start sending frames
                if (frameIntervalRef.current) clearInterval(frameIntervalRef.current);
                frameIntervalRef.current = setInterval(captureAndSendFrame, 1000);
            } else {
                // If unmounted during await, stop tracks immediately
                stream.getTracks().forEach(t => t.stop());
            }
        } catch (e) {
            console.error("Camera access failed", e);
            if (mountedRef.current) setIsCameraOn(false);
        }
    };

    const captureAndSendFrame = () => {
        if (!videoRef.current || !canvasRef.current || !sessionRef.current || !mountedRef.current) return;
        
        const ctx = canvasRef.current.getContext('2d');
        if (!ctx) return;

        if (videoRef.current.videoWidth === 0 || videoRef.current.videoHeight === 0) return;

        canvasRef.current.width = videoRef.current.videoWidth;
        canvasRef.current.height = videoRef.current.videoHeight;
        ctx.drawImage(videoRef.current, 0, 0);

        // Send as low quality JPEG to keep bandwidth usage reasonable
        const base64Data = canvasRef.current.toDataURL('image/jpeg', 0.5).split(',')[1];
        sessionRef.current.sendVideoFrame(base64Data);
    };

    const toggleCamera = () => {
        if (isCameraOn) {
            // Stop video tracks
            const stream = videoRef.current?.srcObject as MediaStream;
            stream?.getTracks().forEach(t => t.stop());
            if (videoRef.current) videoRef.current.srcObject = null;
            if (frameIntervalRef.current) clearInterval(frameIntervalRef.current);
            setIsCameraOn(false);
        } else {
            setIsCameraOn(true);
            startVideo();
        }
    };

    return (
        <div className="absolute inset-0 bg-black z-50 flex flex-col items-center justify-center">
            {/* Header */}
            <div className="absolute top-6 left-0 right-0 flex justify-center items-center gap-2 text-gray-400">
                <IconLive className="w-5 h-5 text-red-500 animate-pulse" />
                <span className="font-mono text-sm tracking-wider uppercase">{status}</span>
            </div>

            {/* Video Preview */}
            <div className="relative w-full max-w-2xl aspect-video bg-gray-900 rounded-2xl overflow-hidden shadow-2xl border border-gray-800">
                <video 
                    ref={videoRef} 
                    className={`w-full h-full object-cover ${isCameraOn ? 'opacity-100' : 'opacity-0'}`} 
                    muted 
                    playsInline 
                />
                {!isCameraOn && (
                    <div className="absolute inset-0 flex items-center justify-center text-gray-600">
                        <IconVideoOff className="w-16 h-16" />
                    </div>
                )}
                <canvas ref={canvasRef} className="hidden" />
                
                {/* Overlay for audio viz simulation */}
                <div className="absolute bottom-4 left-4 right-4 flex justify-center">
                     <div className="flex gap-1 items-end h-8">
                        <div className="w-1 bg-blue-500 animate-[bounce_1s_infinite] h-4"></div>
                        <div className="w-1 bg-blue-500 animate-[bounce_1.2s_infinite] h-6"></div>
                        <div className="w-1 bg-blue-500 animate-[bounce_0.8s_infinite] h-3"></div>
                     </div>
                </div>
            </div>

            {/* Controls */}
            <div className="mt-8 flex items-center gap-6">
                 <button 
                    onClick={toggleCamera}
                    className={`p-4 rounded-full transition-all ${isCameraOn ? 'bg-gray-800 hover:bg-gray-700 text-white' : 'bg-red-500/20 text-red-500'}`}
                 >
                     {isCameraOn ? <IconVideoOn className="w-6 h-6" /> : <IconVideoOff className="w-6 h-6" />}
                 </button>

                 <button 
                    onClick={onClose}
                    className="p-4 bg-red-600 hover:bg-red-700 text-white rounded-full shadow-lg shadow-red-900/20 transform hover:scale-105 transition-all"
                 >
                     <IconPhoneHangup className="w-8 h-8" />
                 </button>
            </div>

            <div className="absolute bottom-6 text-xs text-gray-600 font-mono">
                Live API Beta • Gemini 2.5 Flash Native
            </div>
        </div>
    );
};

export default LiveSession;