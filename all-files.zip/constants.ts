import { ModelType, GenerationConfig } from './types';

export const DEFAULT_SYSTEM_INSTRUCTION = `You are Adarsh AI, an advanced multimodal assistant.
Your goal is to provide precise, technical, and accurate assistance.
You are an expert in Android development (APK), React, Firebase, and general software engineering.
When asked to code, provide clean, commented, and efficient code.
When asked to analyze images, be descriptive and analytical.
Do not use emojis. Keep responses professional, neutral, fast, and concise.
Focus on exact solutions.`;

export const DEFAULT_CONFIG: GenerationConfig = {
  temperature: 0.7,
  topK: 40,
  topP: 0.95,
  maxOutputTokens: 8192,
  systemInstruction: DEFAULT_SYSTEM_INSTRUCTION
};

export const MODEL_LABELS: Record<string, string> = {
  [ModelType.GeminiFlash]: 'Gemini 2.5 Flash (Fast)',
  [ModelType.GeminiPro]: 'Gemini 3.0 Pro (Reasoning)',
  [ModelType.GeminiFlashImage]: 'Gemini 2.5 Flash Image',
  [ModelType.GeminiProImage]: 'Gemini 3.0 Pro Image',
};