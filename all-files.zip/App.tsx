import React, { useState, useRef, useEffect } from 'react';
import { AppMode, Message, ModelType, GenerationConfig, Attachment } from './types';
import { DEFAULT_CONFIG } from './constants';
import Sidebar from './components/Sidebar';
import ConfigPanel from './components/ConfigPanel';
import MessageBubble from './components/MessageBubble';
import LiveSession from './components/LiveSession';
import { IconSend, IconPlus, IconLoader, IconMic, IconStop, IconFile } from './components/Icons';
import { generateChatStream, generateImage, editImage } from './services/geminiService';
import { Content, Part } from '@google/genai';

const App: React.FC = () => {
  // --- State ---
  const [mode, setMode] = useState<AppMode>(AppMode.Chat);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [config, setConfig] = useState<GenerationConfig>(DEFAULT_CONFIG);
  const [selectedModel, setSelectedModel] = useState<string>(ModelType.GeminiFlash);
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  
  // Speech Recognition State
  const [isRecording, setIsRecording] = useState(false);
  const recognitionRef = useRef<any>(null);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // --- Effects ---

  // Scroll to bottom on new message
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Reset messages/config when mode changes
  useEffect(() => {
    setMessages([]);
    setAttachments([]);
    setInput('');
    setIsRecording(false);
    if (recognitionRef.current) recognitionRef.current.stop();
    
    if (mode === AppMode.Chat) setSelectedModel(ModelType.GeminiFlash);
    if (mode === AppMode.ImageGen) setSelectedModel(ModelType.GeminiFlashImage);
    if (mode === AppMode.ImageEdit) setSelectedModel(ModelType.GeminiFlashImage);
    
  }, [mode]);

  // Setup Speech Recognition
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      if (SpeechRecognition) {
        recognitionRef.current = new SpeechRecognition();
        recognitionRef.current.continuous = false; // Simple dictation
        recognitionRef.current.interimResults = false;
        recognitionRef.current.lang = 'en-US';

        recognitionRef.current.onresult = (event: any) => {
          const transcript = event.results[0][0].transcript;
          if (transcript) {
             setInput(prev => {
                const spacer = prev.length > 0 && !prev.endsWith(' ') ? ' ' : '';
                return prev + spacer + transcript;
             });
          }
          setIsRecording(false);
        };

        recognitionRef.current.onerror = (event: any) => {
          console.error("Speech recognition error:", event.error);
          setIsRecording(false);
        };
        
        recognitionRef.current.onend = () => {
          setIsRecording(false);
        };
      }
    }
  }, []);

  // --- Handlers ---

  const toggleRecording = () => {
    if (!recognitionRef.current) {
      alert("Speech recognition not supported in this browser.");
      return;
    }
    if (isRecording) {
      recognitionRef.current.stop();
    } else {
      recognitionRef.current.start();
      setIsRecording(true);
    }
  };

  const getMimeType = (file: File): string => {
    // Map extension to mime type if browser detection fails or is generic
    if (file.type) return file.type;
    const ext = file.name.split('.').pop()?.toLowerCase();
    switch(ext) {
        case 'js': return 'text/javascript';
        case 'ts': return 'text/x-typescript';
        case 'py': return 'text/x-python';
        case 'json': return 'application/json';
        case 'csv': return 'text/csv';
        case 'md': return 'text/markdown';
        case 'txt': return 'text/plain';
        case 'html': return 'text/html';
        case 'css': return 'text/css';
        default: return 'text/plain';
    }
  };

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const reader = new FileReader();
      
      reader.onload = (ev) => {
        if (ev.target?.result) {
          const base64 = (ev.target.result as string).split(',')[1];
          const mimeType = getMimeType(file);
          
          const newAttachment: Attachment = {
            file,
            base64,
            mimeType,
            previewUrl: mimeType.startsWith('image/') ? URL.createObjectURL(file) : ''
          };
          setAttachments(prev => [...prev, newAttachment]);
        }
      };
      reader.readAsDataURL(file);
    }
    // Reset input so same file can be selected again
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleSendMessage = async () => {
    if ((!input.trim() && attachments.length === 0) || isGenerating) return;

    // Validation for Image Edit mode
    if (mode === AppMode.ImageEdit && attachments.length === 0) {
        alert("Please attach an image to edit.");
        return;
    }

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      text: input,
      timestamp: Date.now(),
      // Populate attachments
      attachments: attachments.map(a => ({
          inlineData: { data: a.base64, mimeType: a.mimeType },
          name: a.file.name,
          fileUri: a.previewUrl || undefined
      })),
      // Backward compatibility for simple image display
      imageUri: attachments.find(a => a.mimeType.startsWith('image/'))?.previewUrl
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    const currentAttachments = [...attachments];
    setAttachments([]); // Clear attachments immediately after sending
    setIsGenerating(true);

    const botMessageId = (Date.now() + 1).toString();
    
    // Placeholder for bot message
    const botPlaceholder: Message = {
      id: botMessageId,
      role: 'model',
      text: '',
      timestamp: Date.now(),
      isLoading: true
    };
    setMessages(prev => [...prev, botPlaceholder]);

    try {
      if (mode === AppMode.Chat) {
        // Construct history properly including previous attachments
        const history: Content[] = messages.map(m => {
            const parts: Part[] = [];
            
            // Add previous attachments
            if (m.attachments && m.attachments.length > 0) {
                m.attachments.forEach(att => {
                    parts.push({ inlineData: att.inlineData });
                });
            } 
            // Fallback for old messages with imageUri but no attachment structure (if any)
            else if (m.imageUri && m.role === 'user') {
                 // This path is unlikely for new messages but safe for types
            }

            // Add text
            if (m.text && m.text.trim()) {
                parts.push({ text: m.text });
            } else if (parts.length === 0) {
                parts.push({ text: '[User sent a file]' });
            }
            return {
                role: m.role,
                parts: parts
            };
        });

        const apiAttachments = currentAttachments.map(a => ({
            data: a.base64,
            mimeType: a.mimeType
        }));

        await generateChatStream(
            selectedModel,
            history,
            userMessage.text || '',
            apiAttachments,
            config,
            (chunk) => {
                setMessages(prev => prev.map(m => 
                    m.id === botMessageId 
                    ? { ...m, text: chunk, isLoading: false } 
                    : m
                ));
            }
        );
      } 
      
      else if (mode === AppMode.ImageGen) {
         const imageUrl = await generateImage(userMessage.text || '', selectedModel);
         setMessages(prev => prev.map(m => 
             m.id === botMessageId
             ? { ...m, text: 'Generated Image:', imageUri: imageUrl, isLoading: false }
             : m
         ));
      }

      else if (mode === AppMode.ImageEdit) {
          const sourceImage = currentAttachments[0];
          if (!sourceImage.mimeType.startsWith('image/')) {
              throw new Error("Please provide an image file for editing.");
          }
          const editedImageUrl = await editImage(sourceImage.base64, sourceImage.mimeType, userMessage.text || 'Edit this image', selectedModel);
          setMessages(prev => prev.map(m =>
              m.id === botMessageId
              ? { ...m, text: 'Edited Image:', imageUri: editedImageUrl, isLoading: false }
              : m
          ));
      }

    } catch (error) {
      console.error("API Error:", error);
      let errorMessage = (error as Error).message || "An unknown error occurred";

      // Attempt to parse JSON error strings from SDK
      try {
          const jsonMatch = errorMessage.match(/\{[\s\S]*\}/);
          if (jsonMatch) {
              const parsed = JSON.parse(jsonMatch[0]);
              if (parsed.error?.message) {
                  errorMessage = parsed.error.message;
              }
          }
      } catch (e) {
          // Parsing failed, use raw message
      }
      
      // Specific Handling for 404 / Not Found
      if (errorMessage.includes('Requested entity was not found') || errorMessage.includes('404')) {
          errorMessage = "Model not found (404). Please check your API key permissions or try a different model.";
      }

      setMessages(prev => prev.map(m => 
        m.id === botMessageId
        ? { ...m, text: `Error: ${errorMessage}`, isLoading: false, error: true }
        : m
      ));
    } finally {
      setIsGenerating(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <div className="flex min-h-screen bg-gray-900 text-gray-200 font-sans overflow-hidden">
      {/* Sidebar */}
      <Sidebar 
        currentMode={mode} 
        setMode={setMode} 
        onNewSession={() => setMessages([])} 
      />

      {/* Main Area */}
      <main className="flex-1 flex flex-col relative h-screen">
        
        {/* Live Session Overlay */}
        {mode === AppMode.Live && (
            <LiveSession onClose={() => setMode(AppMode.Chat)} />
        )}

        {/* Mobile Header */}
        <div className="md:hidden p-4 border-b border-gray-800 bg-gray-950 flex items-center justify-between">
            <span className="font-bold text-white">Adarsh AI</span>
            <select 
                value={mode}
                onChange={(e) => setMode(e.target.value as AppMode)}
                className="bg-gray-800 text-xs p-1 rounded text-white"
            >
                <option value={AppMode.Chat}>Chat</option>
                <option value={AppMode.Live}>Live</option>
                <option value={AppMode.ImageGen}>Image</option>
                <option value={AppMode.ImageEdit}>Edit</option>
            </select>
        </div>

        {/* Chat/Content Area (Hidden if Live mode is active but usually handled by overlay) */}
        <div className="flex-1 overflow-y-auto p-4 md:p-8 scroll-smooth">
           <div className="max-w-3xl mx-auto">
             {messages.length === 0 && mode !== AppMode.Live && (
                 <div className="flex flex-col items-center justify-center h-[60vh] text-center text-gray-500">
                     <div className="w-16 h-16 bg-gray-800 rounded-2xl mb-6 flex items-center justify-center">
                         {mode === AppMode.Chat && <div className="w-8 h-8 bg-blue-500 rounded-full" />}
                         {mode === AppMode.ImageGen && <div className="w-8 h-8 bg-purple-500 rounded-full" />}
                         {mode === AppMode.ImageEdit && <div className="w-8 h-8 bg-orange-500 rounded-full" />}
                     </div>
                     <h2 className="text-2xl font-semibold text-white mb-2">
                        {mode === AppMode.Chat && 'How can I help you today?'}
                        {mode === AppMode.ImageGen && 'Describe the image you want to create.'}
                        {mode === AppMode.ImageEdit && 'Upload an image and describe how to edit it.'}
                     </h2>
                     <p className="max-w-md text-sm">
                        Adarsh AI can help with analysis, code, images, editing, and complex reasoning tasks.
                     </p>
                 </div>
             )}
             
             {messages.map(msg => (
               <MessageBubble key={msg.id} message={msg} />
             ))}
             
             <div ref={messagesEndRef} />
           </div>
        </div>

        {/* Input Area - Disabled/Hidden in Live Mode */}
        {mode !== AppMode.Live && (
        <div className="p-4 border-t border-gray-800 bg-gray-900/50 backdrop-blur-sm">
           <div className="max-w-3xl mx-auto relative">
              {/* Attachment Previews */}
              {attachments.length > 0 && (
                  <div className="flex flex-wrap gap-2 mb-2 px-2">
                      {attachments.map((att, idx) => (
                          <div key={idx} className="relative group border border-gray-700 rounded-md overflow-hidden bg-gray-800">
                              {att.mimeType.startsWith('image/') ? (
                                  <div className="w-16 h-16">
                                     <img src={att.previewUrl} className="w-full h-full object-cover" alt="preview" />
                                  </div>
                              ) : (
                                  <div className="w-24 h-16 flex flex-col items-center justify-center p-2 text-xs text-gray-300">
                                      <IconFile className="w-6 h-6 mb-1 text-blue-400" />
                                      <span className="truncate w-full text-center">{att.file.name}</span>
                                  </div>
                              )}
                              <button 
                                onClick={() => setAttachments(prev => prev.filter((_, i) => i !== idx))}
                                className="absolute top-0 right-0 bg-black/60 hover:bg-black/80 text-white p-0.5 rounded-bl transition-colors"
                                title="Remove"
                              >
                                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-3 h-3">
                                      <line x1="18" y1="6" x2="6" y2="18"></line>
                                      <line x1="6" y1="6" x2="18" y2="18"></line>
                                  </svg>
                              </button>
                          </div>
                      ))}
                  </div>
              )}

              <div className="bg-gray-800 rounded-2xl border border-gray-700 focus-within:border-blue-500/50 focus-within:ring-1 focus-within:ring-blue-500/20 transition-all flex flex-col">
                 <textarea
                   value={input}
                   onChange={(e) => setInput(e.target.value)}
                   onKeyDown={handleKeyDown}
                   placeholder={
                       isRecording ? "Listening..." :
                       mode === AppMode.Chat ? "Message Adarsh AI..." :
                       mode === AppMode.ImageGen ? "Describe image..." : "Instruction (e.g. 'Make it cybernetic')..."
                   }
                   className={`w-full bg-transparent border-none text-white placeholder-gray-500 px-4 py-3 focus:ring-0 resize-none min-h-[50px] max-h-[200px] ${isRecording ? 'animate-pulse' : ''}`}
                   rows={1}
                 />
                 
                 <div className="flex items-center justify-between px-2 pb-2">
                    <div className="flex items-center gap-1">
                        {/* Attachment Button - Available in Chat AND Image Edit */}
                        {(mode === AppMode.Chat || mode === AppMode.ImageEdit) && (
                            <>
                                <input 
                                    type="file" 
                                    ref={fileInputRef} 
                                    className="hidden" 
                                    onChange={handleFileSelect} 
                                    // Accept broad range of document/code types
                                    accept="image/*,application/pdf,text/plain,text/csv,application/json,text/markdown,text/html,text/css,.js,.ts,.py,.java,.cpp,.c,.h,.php,.rb,.go,.rs,.swift"
                                />
                                <button 
                                    onClick={() => fileInputRef.current?.click()}
                                    className="p-2 text-gray-400 hover:text-white hover:bg-gray-700 rounded-full transition-colors"
                                    title="Attach files (Image, PDF, Code, Text)"
                                >
                                    <IconPlus className="w-5 h-5" />
                                </button>
                            </>
                        )}
                        
                        {/* Microphone Button */}
                        <button
                            onClick={toggleRecording}
                            className={`p-2 rounded-full transition-colors ${isRecording ? 'text-red-500 bg-red-500/10 animate-pulse' : 'text-gray-400 hover:text-white hover:bg-gray-700'}`}
                            title="Speak"
                        >
                            {isRecording ? <IconStop className="w-5 h-5" /> : <IconMic className="w-5 h-5" />}
                        </button>
                    </div>

                    <button
                        onClick={handleSendMessage}
                        disabled={(!input.trim() && attachments.length === 0) || isGenerating}
                        className={`p-2 rounded-xl transition-all ${
                            (input.trim() || attachments.length > 0) && !isGenerating
                            ? 'bg-white text-gray-900 hover:bg-gray-200'
                            : 'bg-gray-700 text-gray-500 cursor-not-allowed'
                        }`}
                    >
                        {isGenerating ? <IconLoader className="w-5 h-5" /> : <IconSend className="w-5 h-5" />}
                    </button>
                 </div>
              </div>
              
              <div className="text-center mt-2">
                  <p className="text-[10px] text-gray-500">
                      Adarsh AI may display inaccurate info, including about people, so double-check its responses.
                  </p>
              </div>
           </div>
        </div>
        )}
      </main>

      {/* Config Panel - Hidden during Live Mode */}
      {mode !== AppMode.Live && (
      <ConfigPanel 
        mode={mode}
        config={config} 
        setConfig={setConfig}
        selectedModel={selectedModel}
        setModel={setSelectedModel}
      />
      )}
    </div>
  );
};

export default App;