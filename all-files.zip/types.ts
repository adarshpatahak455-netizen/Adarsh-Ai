
export enum AppMode {
  Chat = 'CHAT',
  ImageGen = 'IMAGE_GEN',
  ImageEdit = 'IMAGE_EDIT',
  Live = 'LIVE',
}

export enum ModelType {
  GeminiFlash = 'gemini-2.5-flash',
  GeminiPro = 'gemini-3-pro-preview',
  GeminiFlashImage = 'gemini-2.5-flash-image',
  GeminiProImage = 'gemini-3-pro-image-preview',
  GeminiLive = 'gemini-2.5-flash-native-audio-preview-09-2025',
}

export interface Message {
  id: string;
  role: 'user' | 'model' | 'system';
  text?: string;
  imageUri?: string; // Kept for backward compatibility/display
  attachments?: {
      inlineData: {
          data: string;
          mimeType: string;
      };
      fileUri?: string; // For display
      name?: string; // File name
  }[];
  timestamp: number;
  isLoading?: boolean;
  error?: boolean;
}

export interface ChatSession {
  id: string;
  title: string;
  messages: Message[];
  mode: AppMode;
  model: string;
}

export interface GenerationConfig {
  temperature: number;
  topK: number;
  topP: number;
  maxOutputTokens: number;
  systemInstruction?: string;
}

export interface Attachment {
  file: File;
  base64: string;
  mimeType: string;
  previewUrl: string;
}
