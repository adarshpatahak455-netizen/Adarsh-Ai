import { GoogleGenAI, GenerateContentResponse, Content, Part, LiveServerMessage, Modality, Blob } from "@google/genai";
import { GenerationConfig, ModelType } from "../types";

// Helper to ensure we have an instance with the latest key
const getAIClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    throw new Error("API Key not found in environment variables.");
  }
  return new GoogleGenAI({ apiKey });
};

// Helper to handle API Key selection/retry flow
const runWithKeyRetry = async <T>(
  operation: (ai: GoogleGenAI) => Promise<T>
): Promise<T> => {
  try {
    const ai = getAIClient();
    return await operation(ai);
  } catch (error: any) {
    let errStr = '';
    
    // Robustly stringify error to catch hidden JSON
    if (typeof error === 'object' && error !== null) {
        // If it has a nested error object (common in Google APIs)
        if (error.error) {
            errStr = JSON.stringify(error);
        } else {
            errStr = JSON.stringify(error) + ' ' + (error.message || '');
        }
    } else {
        errStr = String(error);
    }

    // Attempt to extract JSON error details if present in the string
    try {
       const jsonMatch = errStr.match(/\{[\s\S]*\}/);
       if (jsonMatch) {
          const parsed = JSON.parse(jsonMatch[0]);
          if (parsed.error?.message) errStr += ` ${parsed.error.message}`;
          if (parsed.error?.code) errStr += ` ${parsed.error.code}`;
          if (parsed.message) errStr += ` ${parsed.message}`;
       }
    } catch(e) {
       // If parsing fails, rely on original string
    }

    // Check for 404/Not Found (Model missing) or 403/PermissionDenied (Invalid Key)
    const isAccessError = 
      errStr.includes('Requested entity was not found') || 
      errStr.includes('404') || 
      errStr.includes('403') ||
      errStr.includes('PERMISSION_DENIED') ||
      errStr.includes('API key not valid');

    if (isAccessError) {
      // @ts-ignore
      if (typeof window !== 'undefined' && window.aistudio && window.aistudio.openSelectKey) {
        console.warn("Access error detected (403/404), prompting key selection...");
        // @ts-ignore
        await window.aistudio.openSelectKey();
        
        // Wait a moment for the new key to propagate to process.env
        await new Promise(resolve => setTimeout(resolve, 1500));

        // Retry with fresh client (which picks up new process.env.API_KEY)
        const ai = getAIClient();
        try {
            return await operation(ai);
        } catch (retryError: any) {
             // If it fails again with 404, it means the USER'S key simply doesn't have access.
             // We throw a clear error for the UI to display.
             const retryErrStr = JSON.stringify(retryError);
             if (retryErrStr.includes('404') || retryErrStr.includes('Requested entity was not found')) {
                 throw new Error("Access Denied: The selected API Key does not have access to this model (404). Please verify your Google Cloud project has the correct API enabled and billing set up.");
             }
             throw retryError;
        }
      }
    }
    throw error;
  }
};

// --- Text & Vision Chat ---

export const generateChatStream = async (
  modelName: string,
  history: Content[],
  lastMessage: string,
  attachments: { data: string; mimeType: string }[], // Changed from images to attachments
  config: GenerationConfig,
  onChunk: (text: string) => void
): Promise<string> => {
  
  return runWithKeyRetry(async (ai) => {
    // Construct the current message parts
    const currentParts: Part[] = [];
    
    // Add attachments if present
    attachments.forEach(att => {
      currentParts.push({
        inlineData: {
          data: att.data,
          mimeType: att.mimeType
        }
      });
    });

    // Add text - ensure strictly non-empty
    const cleanText = lastMessage ? lastMessage.trim() : '';
    if (cleanText) {
      currentParts.push({ text: cleanText });
    } 
    
    // If both text and attachments are missing, add a placeholder to avoid API error
    if (currentParts.length === 0) {
      currentParts.push({ text: '.' });
    }

    // Filter history to ensure only user/model roles are passed and parts are valid
    const validHistory = history.filter(h => 
      (h.role === 'user' || h.role === 'model') && 
      h.parts && h.parts.length > 0 &&
      // Ensure at least one part is valid
      h.parts.some(p => (p.text && p.text.trim().length > 0) || p.inlineData)
    );

    const chat = ai.chats.create({
      model: modelName,
      history: validHistory,
      config: {
        temperature: config.temperature,
        topK: config.topK,
        topP: config.topP,
        maxOutputTokens: config.maxOutputTokens,
        systemInstruction: config.systemInstruction,
      },
    });

    const resultStream = await chat.sendMessageStream({
      message: { 
        role: 'user',
        parts: currentParts 
      }
    });

    let fullText = '';
    for await (const chunk of resultStream) {
      const text = (chunk as GenerateContentResponse).text;
      if (text) {
        fullText += text;
        onChunk(fullText);
      }
    }
    return fullText;
  });
};

// --- Vision Specific API ---

export const analyzeImage = async (
    base64: string, 
    mimeType: string, 
    prompt: string = "Describe this image in detail."
): Promise<string> => {
    return runWithKeyRetry(async (ai) => {
      const response = await ai.models.generateContent({
          model: ModelType.GeminiFlash,
          contents: {
              parts: [
                  { inlineData: { data: base64, mimeType } },
                  { text: prompt }
              ]
          }
      });
      return response.text || "No description generated.";
    });
};

// --- Image Generation (Stability AI) ---

const generateImageStability = async (prompt: string): Promise<string> => {
    const apiKey = process.env.STABILITY_API_KEY;
    if (!apiKey) throw new Error("Stability API Key not found");

    try {
        const response = await fetch(
            "https://api.stability.ai/v1/generation/stable-diffusion-xl-1024-v1-0/text-to-image",
            {
              method: "POST",
              headers: {
                "Content-Type": "application/json",
                Accept: "application/json",
                Authorization: `Bearer ${apiKey}`,
              },
              body: JSON.stringify({
                text_prompts: [{ text: prompt }],
                cfg_scale: 7,
                height: 1024,
                width: 1024,
                samples: 1,
                steps: 30,
              }),
            }
        );

        if (!response.ok) {
            throw new Error(`Stability API Error: ${response.status} ${response.statusText}`);
        }

        const data = await response.json();
        const imageBase64 = data.artifacts?.[0]?.base64;
        
        if (!imageBase64) throw new Error("No image artifact returned from Stability AI");
        
        return `data:image/png;base64,${imageBase64}`;
    } catch (e) {
        console.warn("Stability AI failed, falling back to Gemini Image Generation", e);
        throw e; 
    }
};

export const generateImage = async (
  prompt: string,
  modelName: string = ModelType.GeminiFlashImage
): Promise<string> => {
  
  try {
      return await generateImageStability(prompt);
  } catch (error) {
      // Fallback to Gemini
      return runWithKeyRetry(async (ai) => {
        const response = await ai.models.generateContent({
          model: modelName,
          contents: { parts: [{ text: prompt }] },
        });

        const parts = response.candidates?.[0]?.content?.parts;
        if (!parts) throw new Error("No content generated");

        for (const part of parts) {
          if (part.inlineData && part.inlineData.data) {
            return `data:${part.inlineData.mimeType || 'image/png'};base64,${part.inlineData.data}`;
          }
        }
        throw new Error("Image generation failed (Stability & Gemini)");
      });
  }
};

// --- Image Editing ---

export const editImage = async (
  imageBase64: string,
  imageMimeType: string,
  prompt: string,
  modelName: string = ModelType.GeminiFlashImage
): Promise<string> => {
   return runWithKeyRetry(async (ai) => {
      const response = await ai.models.generateContent({
          model: modelName,
          contents: {
            parts: [
               { inlineData: { data: imageBase64, mimeType: imageMimeType }},
               { text: prompt }
            ]
          }
      });
      
      // Parse for image in response
      const parts = response.candidates?.[0]?.content?.parts;
      if(parts) {
          for(const part of parts) {
              if(part.inlineData && part.inlineData.data) {
                  return `data:${part.inlineData.mimeType || 'image/png'};base64,${part.inlineData.data}`;
              }
          }
      }
      throw new Error("No edited image returned by the model. Ensure the model supports image output.");
   });
}

// --- Live API Helpers ---

function base64ToUint8Array(base64: string): Uint8Array {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

function uint8ArrayToBase64(bytes: Uint8Array): string {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

function createPcmBlob(data: Float32Array): Blob {
  const l = data.length;
  const int16 = new Int16Array(l);
  for (let i = 0; i < l; i++) {
    int16[i] = data[i] * 32768;
  }
  return {
    data: uint8ArrayToBase64(new Uint8Array(int16.buffer)),
    mimeType: 'audio/pcm;rate=16000',
  };
}

async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number = 24000,
  numChannels: number = 1
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

export class GeminiLiveSession {
  private ai: GoogleGenAI;
  private sessionPromise: Promise<any> | null = null;
  private inputAudioContext: AudioContext | null = null;
  private outputAudioContext: AudioContext | null = null;
  private stream: MediaStream | null = null;
  private nextStartTime: number = 0;
  private sources: Set<AudioBufferSourceNode> = new Set();
  private isConnected: boolean = false;

  constructor() {
    this.ai = getAIClient();
  }

  async start(onStatusChange: (status: string) => void) {
    try {
      onStatusChange("Requesting permissions...");
      this.stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      
      this.inputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      this.outputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });

      // Ensure audio contexts are running (browsers may suspend them)
      if (this.inputAudioContext.state === 'suspended') await this.inputAudioContext.resume();
      if (this.outputAudioContext.state === 'suspended') await this.outputAudioContext.resume();

      onStatusChange("Connecting to Adarsh AI Live...");
      
      this.sessionPromise = this.ai.live.connect({
        model: ModelType.GeminiLive,
        config: {
           responseModalities: [Modality.AUDIO],
           speechConfig: {
             voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } },
           },
           systemInstruction: "You are Adarsh AI, a helpful and technical multimodal assistant. Keep responses concise and conversational.",
        },
        callbacks: {
          onopen: () => {
            onStatusChange("Connected (Listening)");
            this.isConnected = true;
            this.startAudioInput();
          },
          onmessage: async (message: LiveServerMessage) => {
            const audioData = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (audioData && this.outputAudioContext) {
               this.playAudioChunk(audioData);
            }
            
            if (message.serverContent?.interrupted) {
               this.stopAudioPlayback();
               this.nextStartTime = 0;
            }
          },
          onclose: () => {
            onStatusChange("Disconnected");
            this.isConnected = false;
          },
          onerror: (e) => {
             console.error("Live API Error", e);
             onStatusChange("Error detected");
          }
        }
      });
    } catch (e) {
      console.error(e);
      onStatusChange("Connection Failed");
      // If this fails immediately, it's likely an auth or model issue.
      throw e;
    }
  }

  private startAudioInput() {
    if (!this.inputAudioContext || !this.stream) return;

    const source = this.inputAudioContext.createMediaStreamSource(this.stream);
    const scriptProcessor = this.inputAudioContext.createScriptProcessor(4096, 1, 1);

    scriptProcessor.onaudioprocess = (e) => {
       if (!this.isConnected || !this.sessionPromise) return;
       
       const inputData = e.inputBuffer.getChannelData(0);
       const pcmBlob = createPcmBlob(inputData);

       this.sessionPromise.then(session => {
          session.sendRealtimeInput({ media: pcmBlob });
       });
    };

    source.connect(scriptProcessor);
    scriptProcessor.connect(this.inputAudioContext.destination);
  }

  private async playAudioChunk(base64Audio: string) {
    if (!this.outputAudioContext) return;

    try {
       this.nextStartTime = Math.max(this.nextStartTime, this.outputAudioContext.currentTime);
       const audioBuffer = await decodeAudioData(
          base64ToUint8Array(base64Audio),
          this.outputAudioContext
       );
       
       const source = this.outputAudioContext.createBufferSource();
       source.buffer = audioBuffer;
       source.connect(this.outputAudioContext.destination);
       
       source.addEventListener('ended', () => this.sources.delete(source));
       source.start(this.nextStartTime);
       
       this.nextStartTime += audioBuffer.duration;
       this.sources.add(source);
    } catch (e) {
       console.error("Audio decode error", e);
    }
  }

  private stopAudioPlayback() {
    this.sources.forEach(s => s.stop());
    this.sources.clear();
  }

  async sendVideoFrame(base64Data: string) {
    if (this.isConnected && this.sessionPromise) {
       const session = await this.sessionPromise;
       session.sendRealtimeInput({
          media: {
             mimeType: 'image/jpeg',
             data: base64Data
          }
       });
    }
  }

  disconnect() {
    this.isConnected = false;
    this.stopAudioPlayback();
    
    if (this.stream) {
      this.stream.getTracks().forEach(t => t.stop());
    }
    if (this.inputAudioContext) this.inputAudioContext.close();
    if (this.outputAudioContext) this.outputAudioContext.close();
    
    if (this.sessionPromise) {
        this.sessionPromise.then(s => {
            // Try to close cleanly
            try { if (s.close) s.close(); } catch (e) {}
        });
    }
  }
}